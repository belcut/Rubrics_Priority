﻿using System.Windows.Controls;

namespace Showcase.WPF.DragDrop.Views
{
    /// <summary>
    /// Interaction logic for Issues.xaml
    /// </summary>
    public partial class Issues : UserControl
    {
        public Issues()
        {
            InitializeComponent();
        }
    }
}