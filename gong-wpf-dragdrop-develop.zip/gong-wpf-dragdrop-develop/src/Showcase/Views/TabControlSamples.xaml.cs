﻿using System.Windows.Controls;

namespace Showcase.WPF.DragDrop.Views
{
    /// <summary>
    /// Interaction logic for TabControlSamples.xaml
    /// </summary>
    public partial class TabControlSamples : UserControl
    {
        public TabControlSamples()
        {
            InitializeComponent();
        }
    }
}