﻿using System.Windows.Controls;

namespace Showcase.WPF.DragDrop.Views
{
    /// <summary>
    /// Interaction logic for ListBoxSample.xaml
    /// </summary>
    public partial class ListBoxSamples : UserControl
    {
        public ListBoxSamples()
        {
            InitializeComponent();
        }
    }
}