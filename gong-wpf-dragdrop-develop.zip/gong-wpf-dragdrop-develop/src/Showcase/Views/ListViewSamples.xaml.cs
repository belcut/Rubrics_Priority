﻿using System.Windows.Controls;

namespace Showcase.WPF.DragDrop.Views
{
    /// <summary>
    /// Interaction logic for ListViewSample.xaml
    /// </summary>
    public partial class ListViewSamples : UserControl
    {
        public ListViewSamples()
        {
            InitializeComponent();
        }
    }
}