﻿using System.Windows.Controls;

namespace Showcase.WPF.DragDrop.Views
{
    /// <summary>
    /// Interaction logic for DataGridSamples.xaml
    /// </summary>
    public partial class DataGridSamples : UserControl
    {
        public DataGridSamples()
        {
            InitializeComponent();
        }
    }
}