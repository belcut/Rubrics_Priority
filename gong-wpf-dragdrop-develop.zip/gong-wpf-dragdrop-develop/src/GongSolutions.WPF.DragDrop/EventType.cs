﻿namespace GongSolutions.Wpf.DragDrop
{
    public enum EventType
    {
        Auto,
        Tunneled,
        Bubbled,
        TunneledBubbled
    }
}